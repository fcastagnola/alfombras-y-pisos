<?
while(list($nombre_campo, $valor_campo ) = each($HTTP_POST_VARS )) {
strtolower ($nombre_campo);


if(is_array($valor_campo)){
$msg .= ucfirst($nombre_campo).": \n";

while (list ($val) = each ($valor_campo)) {
$msg .= $val."\n";
}
$msg .= "\n";
}else{
if($nombre_campo != "submit" && $nombre_campo !="receptor" && $nombre_campo !="remitente" && $nombre_campo !="tema" && $nombre_campo !="redireccion"){
$msg .= ucfirst($nombre_campo).": ".$valor_campo."\n\n"; }
}

}

$msg .= "----------------------------------------------\n";
$msg .= "IP: ".$REMOTE_ADDR."\n";

mail($receptor,$tema,$msg,"From: $remitente");
header("Location: gracias.htm");
?>
