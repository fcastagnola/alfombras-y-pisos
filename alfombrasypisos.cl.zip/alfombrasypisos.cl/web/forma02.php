<?
$destinatario = $_REQUEST["destino"];
while(list($nombre_campo, $valor_campo ) = each($HTTP_POST_VARS )) {
strtolower ($nombre_campo);


if(is_array($valor_campo)){
$msg .= ucfirst($nombre_campo).": \n";

while (list ($val) = each ($valor_campo)) {
$msg .= $val."\n";
}
$msg .= "\n";
}else{
if($nombre_campo != "submit" && $nombre_campo !="receptor" && $nombre_campo !="remitente" && $nombre_campo !="tema" && $nombre_campo !="redireccion"){
$msg .= ucfirst($nombre_campo).": ".$valor_campo."\n\n"; }
}

}

mail($destinatario,"Contacto Sitio Web Alfombras y Pisos",$msg,"From: info@alfombrasypisos.cl");
header("Location: gracias.php");
?>
