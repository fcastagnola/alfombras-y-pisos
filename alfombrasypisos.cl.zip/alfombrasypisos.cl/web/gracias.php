<HTML>
<HEAD>
<TITLE>Alfombras y Pisos / Distribuidora Nacional de Alfombras</TITLE>
<meta name="Subject" content="Alfombras y Pisos Chile">
<meta content="Alfombras y Pisos, Pisos Flotantes, BerryLoc, Beaulieu, Centro de Alfombras y Pisos, Distribuidora Nacional de Alfombras" name=description>
<meta name="Keywords" content="alfombras y pisos,pisos flotantes,BerryLoc,Beaulieu,alfombras,pisos,Alfombras,Distribuidora de Alfombras">
<meta name="Language" content="Spanish">
<meta name="Robots" content="all">
<link rel="stylesheet" href="nnset.css" type="text/css">
<link rel="stylesheet" href="form.css" type="text/css">
<script src="Scripts/AC_RunActiveContent.js" type="text/javascript"></script><script language="JavaScript">
var whitespace = " \t\n\r";
function isEmpty(s)
{   return ((s == null) || (s.length == 0))
}

 function isWhitespace (s)
{   var i;
    if (isEmpty(s)) return true;
    for (i = 0; i < s.length; i++)
    {
        var c = s.charAt(i);
        // si el caracter en que estoy no aparece en whitespace,
        // entonces retornar falso
        if (whitespace.indexOf(c) == -1) return false;
    }
    return true;
}

  function ValidarFormulario() {
    if (isWhitespace(document.form.nombre.value)) {
      alert("Ingrese Nombre");
      return false;
    }

    if (isWhitespace(document.form.fono.value) && isWhitespace(document.form.email.value)) {
      alert("Ingrese Telefono y/o Email");
      return false;
    }
    return true;
  }
</script>
<meta content="text/html; charset=iso-8859-1" http-equiv="Content-Type"><style type="text/css">
<!--
body {
	background-image: url(fot/fondd.jpg);
	background-color: #000000;
	margin-bottom: 15px;
}
-->
</style>
</HEAD>
<BODY leftmargin="0" topmargin="0" marginwidth="0">
<table align="center" border="0" cellspacing="0" cellpadding="0" width="780">
  <tr>
    <td width="780" bgcolor="#FFFFFF"><script type="text/javascript">
AC_FL_RunContent( 'codebase','http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=9,0,28,0','width','780','height','290','src','alf_piso','quality','high','pluginspage','http://www.adobe.com/shockwave/download/download.cgi?P1_Prod_Version=ShockwaveFlash','movie','alf_piso' ); //end AC code
</script> <noscript> <object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=9,0,28,0" width="780" height="290"> <param name="movie" value="alf_piso.swf"> <param name="quality" value="high"> <embed src="alf_piso.swf" quality="high" pluginspage="http://www.adobe.com/shockwave/download/download.cgi?P1_Prod_Version=ShockwaveFlash" type="application/x-shockwave-flash" width="780" height="290"></embed> </object></noscript></td>
  </tr>
  <tr>
    <td bgcolor="#FFFFFF"><img src="fot/tt_cont.jpg" width="780" height="25"></td>
  </tr>
  <tr>
    <td bgcolor="#FFFFFF" background="fot/fondd22.jpg" height="300"><table align="CENTER" width="696" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td class="latin03" valign="TOP" width="345"><div align="CENTER">
          <p>&nbsp;</p>
          <p>&nbsp;</p>
          <p>Gracias por contactarse con nosotros.</p>
        </div></td>
        <td valign="TOP" width="351"><table align="CENTER" cellpadding="0" cellspacing="0" border="0" width="323">
          <tr>
            <td class="cont" width="331"> <strong>DISTRIBUIDORA NACIONAL DE ALFOMBRAS LTDA.</strong></td>
          </tr>
          <tr>
            <td><span class="cont"><img src="fot/lin.jpg" width="320" height="1"></span></td>
          </tr>
          <tr>
            <td class="latin022" height="61" valign="TOP"> <img src="fot/cir_01.jpg" width="15" height="10">AVDA EGA&Ntilde;A N&ordm; 130 LA REINA<br>
                <img src="fot/cir_01.jpg" width="15" height="10">RUT : 77.895.230-0</td>
          </tr>
          <tr>
            <td class="cont"> <strong>LOCALES</strong></td>
          </tr>
          <tr>
            <td><span class="cont"><img src="fot/lin.jpg" width="320" height="1"></span></td>
          </tr>
          <tr>
            <td class="latin022"> <img src="fot/cir_01.jpg" width="15" height="10">Macul<br>
              <img src="fot/cir_01.jpg" width="15" height="10">La Reina<br>
              <img src="fot/cir_01.jpg" width="15" height="10">Las Condes<br>
              <img src="fot/cir_01.jpg" width="15" height="10">La Florida<br>
              <img src="fot/cir_01.jpg" width="15" height="10">Puente Alto<br>
              <img src="fot/cir_01.jpg" width="15" height="10">Shopping Center<br>
              <img src="fot/cir_01.jpg" width="15" height="10">San Felipe<br>
              <img src="fot/cir_01.jpg" width="15" height="10">Providencia<br>
              <img src="fot/cir_01.jpg" width="15" height="10">Vitacura<br>
              <img src="fot/cir_01.jpg" width="15" height="10">Maip&uacute;<br>
              <img src="fot/cir_01.jpg" width="15" height="10">La Dehesa<br>
              <img src="fot/cir_01.jpg" width="15" height="10">Pe&ntilde;alolen</td>
          </tr>
        </table></td>
      </tr>
    </table>    </td>
  </tr>
  <tr bgcolor="#666666">
    <td bgcolor="#FFFFFF"><img src="fot/lin.jpg" width="780" height="1"></td>
  </tr>
  <tr bgcolor="#666666">
    <td bgcolor="#FFFFFF" class="pie"> Distribuidora Nacional de Alfombras y Pisos Flotantes &middot; Santiago de Chile </td>
  </tr>
</table>
</BODY>
</HTML>
