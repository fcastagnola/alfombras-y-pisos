        <form class="login_form" style="color: #CCCCCC" method="post" action="main.php?id=<?php echo($sucursal)?>">
            <div >Ingrese su nombre: <input type="text" name="nombre" /></div>
	    <div><input type="hidden" name="username" value='User1'/></div>
            <div><input type="hidden" name="password" value='qwerty' /></div>
            <div><input type="submit" value="Ingresar" name="Login" /></div>
        </form>
    <!--<div>Puedes usar username "User1" o "User2" o "User3" y contrase&mtilde;a "qwerty" para loguear el sistema</div>-->
